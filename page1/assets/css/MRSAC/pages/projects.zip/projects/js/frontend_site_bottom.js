
$(document).ready(function () {
$('a[id^="menu_link_"]').on("click",function(){
					var val = $(this).data('val');
					get_menu_id(val);
				});
});