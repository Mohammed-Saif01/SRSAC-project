$(document).ready(function () {
	$('.get_menu_id').on('click',function(){
		var id = $(this).attr('id');
		get_menu_id(id);
		});
		});